﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2019PAstAnswer
{
    public partial class Form5 : Form
    {
        Form2 insta;
        public Form5(Form2 instance)
        {
            InitializeComponent();
            this.insta = instance;
            if (insta.books == null)
            {
                MessageBox.Show("Book Array retuened null !!");
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            foreach (Book bk in insta.books)
            {
                if (bk != null)
                    comboBox1.Items.Add(bk.Title);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = 0;
            index= comboBox1.SelectedIndex;
            labeledi.Text = insta.books[index].Edition;
            labelpage.Text = Convert.ToString(insta.books[index].Pages);
            labelprice.Text = Convert.ToString(insta.books[index].Price);
            labelnuc.Text = Convert.ToString(insta.books[index].Nuc);
            labelname.Text = insta.books[index].Author.Name;
            labeldob.Text = Convert.ToString(insta.books[index].Author.Dob);
            labelsex.Text = insta.books[index].Author.Sex;
            labelage.Text = Convert.ToString(insta.books[index].Author.Age);
            pictureBox1.Image = Image.FromFile(insta.books[index].File);
            pictureBox2.Image = Image.FromFile(insta.books[index].Author.File);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insta.Show();
            this.Hide();
        }
    }
}
