﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using University;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Paspaper2024
{
    public partial class ViewStudent : Form
    {
        Dashboard dashboard = null;



        //Dashboard dashboard;
        public ViewStudent(Dashboard dash)
        {
            InitializeComponent();
            this.dashboard = dash;
            foreach (var student in this.dashboard.Students)
            {
                if (student != null)
                {
                    comboBox1.Items.Add(student.Rgnumber);
                }
            }


        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ViewStudent_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin("admin", "admin@is.");
            User user = new User("user", "user@is.");

            if (admin.getName() == "admin")
            {
                Dashboard hm = new Dashboard(admin, true);
                hm.Show();
                this.Hide();
            }
            else
            {
                Dashboard hm = new Dashboard(user, true);
                hm.Show();
                this.Hide();
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Student selectedstudents = dashboard.Students[comboBox1.SelectedIndex];
            textBox2.Text = selectedstudents.Name != "" ? selectedstudents.Name : "";
            if(selectedstudents.Sex != "Female")
            {
                radioButton1.Checked=true;
            }
            else
            {
                radioButton2.Checked = true;
            }
            numericUpDown1.Value = selectedstudents.Age != 0 ? selectedstudents.Age : 0;
            numericUpDown2.Value = selectedstudents.Yearofstudy != 0 ? selectedstudents.Yearofstudy : 0;
            Image image = Image.FromFile(selectedstudents.Imagefilename);
            pictureBox1.Image = image;
            pictureBox1.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);

            Course selectedcourses = selectedstudents.Course;

            foreach (Course course in dashboard.Courses)

            {
                    selectedcourses = course;
                if (course != null && course.Title == selectedcourses.Title)
                {
                    selectedcourses = course;
                    textBox3.Text = selectedcourses.Title;
                    numericUpDown3.Value = selectedcourses.Duration;
                    textBox1.Text = selectedcourses.Faculty;

                }
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
    }
}

