﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using University;

namespace Paspaper2024
{
    public partial class Login : Form
    {
        Admin admin;
        User user;
        public Login()
        {
            InitializeComponent();
            this.admin = new Admin("admin", "admin@is");
            this.user = new User("user", "user@is");
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox2.Text;
            string password = textBox1.Text;

            if (username == "admin" && password == "admin@is.")
            {
                //Admin admin = new Admin(username, password);
                Dashboard hm = new Dashboard(admin,true);
                hm.Show();
                this.Hide();
            }
            else if (username == "user" && password == "user@is.")
            {
               // User user = new User(username, password);
                Dashboard hm1 = new Dashboard(user,true);
                hm1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("username or password Incorrect");
                textBox1.Clear();
                textBox2.Clear();

            }
        }
    }
}
