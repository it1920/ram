﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using University;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Paspaper2024
{
    public partial class AddStudent : Form
    {
        Dashboard dashboard = null;
        string imagefilename = "";
        public AddStudent()
        {
            InitializeComponent();
        }

        public AddStudent(Dashboard dash)
        {
            InitializeComponent();
            this.dashboard = dash;
            foreach (var course in this.dashboard.Courses)
            {
                if (course != null)
                {
                    comboBox1.Items.Add(course.Title);
                }
            }


        }

        private void AddStudent_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                imagefilename = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                pictureBox1.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin("admin", "admin@is.");
            Dashboard dt = new Dashboard(admin, true);
            dt.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string regno = textBox3.Text;
            string name = textBox2.Text;
            int age = (int)numericUpDown1.Value;
            string sex = "";
            if(radioButton1.Checked)
            {
                sex = radioButton1.Text;
            }
            else if (radioButton2.Checked)
            {
                sex = radioButton2.Text;
            }
            int yearofstudy = (int)numericUpDown2.Value;

           
            
           
            Course course = comboBox1.SelectedItem as Course;

            Student newstudent = new Student(regno, name, age, sex, yearofstudy, imagefilename, course);

            dashboard.Students[dashboard.studentcount] = newstudent;




            MessageBox.Show("Student is added!");
            dashboard.Show();
            this.Hide();
            

        }

       


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

