﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University
{
    public partial class Student
    {
        private string rgnumber;
        private string name;
        private int age;
        private string sex;
        private int yearofstudy;
        private string imagefilename;
        private Course course;

        public Student(string rgnumber, string name, int age, string sex, int yearofstudy,string imagefilename,Course course)
        {
            this.rgnumber = rgnumber;
            this.name = name;
            this.age = age;
            this.sex = sex;
            this.yearofstudy = yearofstudy;
            this.imagefilename = imagefilename;
            this.course = course;
        }
    }
}
