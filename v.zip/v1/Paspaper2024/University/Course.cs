﻿using System;
using System.Xml.Linq;

namespace University
{
    public class Course
    {
        private string title;
        private int duration;
        private string facalty;

        public Course(string title, int duration, string facalty)
        {
            this.title = title;
            this.duration = duration;
            this.facalty = facalty;
        }

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }

        public int Duration
        {
            get
            {
                return duration;
            }
            set
            {
                duration = value;
            }
        }


        public string Faculty
        {
            get
            {
                return facalty;
            }
            set
            {
                facalty = value;
            }
        }

    }
}
