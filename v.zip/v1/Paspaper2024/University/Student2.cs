﻿using System;
using System.Collections.Generic;
using System.Text;

namespace University
{
    public partial class Student
    {
        public string Rgnumber
        {
            get
            {
                return rgnumber;
            }
            set
            {
                rgnumber = value;
            }
        }


        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }

        public string Sex
        {
            get
            {
                return sex;
            }
            set
            {
                sex = value;
            }
        }

        public int Yearofstudy
        {
            get
            {
                return yearofstudy;
            }
            set
            {
                yearofstudy = value;
            }
        }


        public string Imagefilename
        {
            get
            {
                return imagefilename;
            }
            set
            {
                imagefilename = value;
            }
        }

       

        public Course Course
        {
            get
            {
                return course;
            }
            set
            {
                course = value;
            }
        }













    }
}
