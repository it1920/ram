﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InfiniteLearnFoundation
{
    public partial class Enrolled : Form
    {
        public Enrolled(User logedinUser,ListBox.SelectedObjectCollection SelectedItems,CheckBox checkBoxQuickGui,CheckBox checkBoxSelfLearnBun,double cost)
        {
            InitializeComponent();
            string text = "";
            text += "Dear " + logedinUser.name;
            text += Environment.NewLine + Environment.NewLine+"You are now enrolled in following courses.";
            for(int i = 0; i < SelectedItems.Count; i++)
            {
                text += Environment.NewLine + SelectedItems[i].ToString();
            }
            text += Environment.NewLine+ Environment.NewLine+"Included additional materials per each courses.";
            if(checkBoxQuickGui.Checked )
            {
                text += Environment.NewLine + checkBoxQuickGui.Text;
            }
            if (checkBoxSelfLearnBun.Checked)
            {
                text += Environment.NewLine + checkBoxSelfLearnBun.Text;
            }
            text += Environment.NewLine + Environment.NewLine + cost+" Has been Charged.";

            txtFinal.Text = text; 


        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Hide();

        }
    }
}
