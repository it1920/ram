﻿namespace InfiniteLearnFoundation
{
    partial class Application
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxAvailCourses = new System.Windows.Forms.ListBox();
            this.lblAvailCourses = new System.Windows.Forms.Label();
            this.checkBoxQuickGui = new System.Windows.Forms.CheckBox();
            this.listBoxCate = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btnEnroll = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonAdva = new System.Windows.Forms.RadioButton();
            this.radioButtonInter = new System.Windows.Forms.RadioButton();
            this.radioButtonBegg = new System.Windows.Forms.RadioButton();
            this.lblCate = new System.Windows.Forms.Label();
            this.lblAddiMate = new System.Windows.Forms.Label();
            this.lblCourses = new System.Windows.Forms.Label();
            this.checkBoxSelfLearnBun = new System.Windows.Forms.CheckBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.groupBoxLevel = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBoxLevel.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxAvailCourses
            // 
            this.listBoxAvailCourses.Enabled = false;
            this.listBoxAvailCourses.FormattingEnabled = true;
            this.listBoxAvailCourses.Location = new System.Drawing.Point(193, 122);
            this.listBoxAvailCourses.Name = "listBoxAvailCourses";
            this.listBoxAvailCourses.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxAvailCourses.Size = new System.Drawing.Size(595, 186);
            this.listBoxAvailCourses.TabIndex = 21;
            // 
            // lblAvailCourses
            // 
            this.lblAvailCourses.AutoSize = true;
            this.lblAvailCourses.Enabled = false;
            this.lblAvailCourses.Location = new System.Drawing.Point(190, 106);
            this.lblAvailCourses.Name = "lblAvailCourses";
            this.lblAvailCourses.Size = new System.Drawing.Size(91, 13);
            this.lblAvailCourses.TabIndex = 20;
            this.lblAvailCourses.Text = "Available Courses";
            // 
            // checkBoxQuickGui
            // 
            this.checkBoxQuickGui.AutoSize = true;
            this.checkBoxQuickGui.Enabled = false;
            this.checkBoxQuickGui.Location = new System.Drawing.Point(30, 353);
            this.checkBoxQuickGui.Name = "checkBoxQuickGui";
            this.checkBoxQuickGui.Size = new System.Drawing.Size(85, 17);
            this.checkBoxQuickGui.TabIndex = 19;
            this.checkBoxQuickGui.Text = "Quick Guide";
            this.checkBoxQuickGui.UseVisualStyleBackColor = true;
            // 
            // listBoxCate
            // 
            this.listBoxCate.Enabled = false;
            this.listBoxCate.FormattingEnabled = true;
            this.listBoxCate.Items.AddRange(new object[] {
            "Programming",
            "Data Science",
            "Software",
            "Mobile development",
            "Database"});
            this.listBoxCate.Location = new System.Drawing.Point(30, 122);
            this.listBoxCate.Name = "listBoxCate";
            this.listBoxCate.Size = new System.Drawing.Size(148, 186);
            this.listBoxCate.TabIndex = 18;
            this.listBoxCate.SelectedIndexChanged += new System.EventHandler(this.listBoxCate_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(340, 670);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 16;
            this.button2.Text = "button1";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnEnroll
            // 
            this.btnEnroll.Enabled = false;
            this.btnEnroll.Location = new System.Drawing.Point(340, 420);
            this.btnEnroll.Name = "btnEnroll";
            this.btnEnroll.Size = new System.Drawing.Size(75, 23);
            this.btnEnroll.TabIndex = 17;
            this.btnEnroll.Text = "Enroll Now";
            this.btnEnroll.UseVisualStyleBackColor = true;
            this.btnEnroll.Click += new System.EventHandler(this.btnEnroll_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblUser);
            this.groupBox1.Controls.Add(this.btnRegister);
            this.groupBox1.Controls.Add(this.btnLogin);
            this.groupBox1.Location = new System.Drawing.Point(543, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(245, 100);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBoxUser";
            // 
            // radioButtonAdva
            // 
            this.radioButtonAdva.AutoSize = true;
            this.radioButtonAdva.Location = new System.Drawing.Point(288, 16);
            this.radioButtonAdva.Name = "radioButtonAdva";
            this.radioButtonAdva.Size = new System.Drawing.Size(68, 17);
            this.radioButtonAdva.TabIndex = 12;
            this.radioButtonAdva.TabStop = true;
            this.radioButtonAdva.Text = "Advance";
            this.radioButtonAdva.UseVisualStyleBackColor = true;
            // 
            // radioButtonInter
            // 
            this.radioButtonInter.AutoSize = true;
            this.radioButtonInter.Location = new System.Drawing.Point(143, 19);
            this.radioButtonInter.Name = "radioButtonInter";
            this.radioButtonInter.Size = new System.Drawing.Size(83, 17);
            this.radioButtonInter.TabIndex = 13;
            this.radioButtonInter.TabStop = true;
            this.radioButtonInter.Text = "Intermediate";
            this.radioButtonInter.UseVisualStyleBackColor = true;
            // 
            // radioButtonBegg
            // 
            this.radioButtonBegg.AutoSize = true;
            this.radioButtonBegg.Location = new System.Drawing.Point(18, 19);
            this.radioButtonBegg.Name = "radioButtonBegg";
            this.radioButtonBegg.Size = new System.Drawing.Size(70, 17);
            this.radioButtonBegg.TabIndex = 14;
            this.radioButtonBegg.TabStop = true;
            this.radioButtonBegg.Text = "Begginer ";
            this.radioButtonBegg.UseVisualStyleBackColor = true;
            // 
            // lblCate
            // 
            this.lblCate.AutoSize = true;
            this.lblCate.Enabled = false;
            this.lblCate.Location = new System.Drawing.Point(27, 106);
            this.lblCate.Name = "lblCate";
            this.lblCate.Size = new System.Drawing.Size(49, 13);
            this.lblCate.TabIndex = 8;
            this.lblCate.Text = "Category";
            // 
            // lblAddiMate
            // 
            this.lblAddiMate.AutoSize = true;
            this.lblAddiMate.Enabled = false;
            this.lblAddiMate.Location = new System.Drawing.Point(12, 327);
            this.lblAddiMate.Name = "lblAddiMate";
            this.lblAddiMate.Size = new System.Drawing.Size(93, 13);
            this.lblAddiMate.TabIndex = 9;
            this.lblAddiMate.Text = "Additional Material";
            // 
            // lblCourses
            // 
            this.lblCourses.AutoSize = true;
            this.lblCourses.Enabled = false;
            this.lblCourses.Location = new System.Drawing.Point(12, 77);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(45, 13);
            this.lblCourses.TabIndex = 10;
            this.lblCourses.Text = "Courses";
            // 
            // checkBoxSelfLearnBun
            // 
            this.checkBoxSelfLearnBun.AutoSize = true;
            this.checkBoxSelfLearnBun.Enabled = false;
            this.checkBoxSelfLearnBun.Location = new System.Drawing.Point(171, 353);
            this.checkBoxSelfLearnBun.Name = "checkBoxSelfLearnBun";
            this.checkBoxSelfLearnBun.Size = new System.Drawing.Size(124, 17);
            this.checkBoxSelfLearnBun.TabIndex = 22;
            this.checkBoxSelfLearnBun.Text = "Self Learning Bundle";
            this.checkBoxSelfLearnBun.UseVisualStyleBackColor = true;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(16, 27);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(92, 13);
            this.lblUser.TabIndex = 10;
            this.lblUser.Text = "Unregistered User";
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(19, 60);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 17;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(126, 60);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 17;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // groupBoxLevel
            // 
            this.groupBoxLevel.Controls.Add(this.radioButtonBegg);
            this.groupBoxLevel.Controls.Add(this.radioButtonInter);
            this.groupBoxLevel.Controls.Add(this.radioButtonAdva);
            this.groupBoxLevel.Enabled = false;
            this.groupBoxLevel.Location = new System.Drawing.Point(15, 17);
            this.groupBoxLevel.Name = "groupBoxLevel";
            this.groupBoxLevel.Size = new System.Drawing.Size(409, 54);
            this.groupBoxLevel.TabIndex = 18;
            this.groupBoxLevel.TabStop = false;
            this.groupBoxLevel.Text = "Level";
            // 
            // Application
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBoxLevel);
            this.Controls.Add(this.checkBoxSelfLearnBun);
            this.Controls.Add(this.listBoxAvailCourses);
            this.Controls.Add(this.lblAvailCourses);
            this.Controls.Add(this.checkBoxQuickGui);
            this.Controls.Add(this.listBoxCate);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnEnroll);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblCate);
            this.Controls.Add(this.lblAddiMate);
            this.Controls.Add(this.lblCourses);
            this.Name = "Application";
            this.Text = "Infinite Learn";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxLevel.ResumeLayout(false);
            this.groupBoxLevel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxAvailCourses;
        private System.Windows.Forms.Label lblAvailCourses;
        private System.Windows.Forms.CheckBox checkBoxQuickGui;
        private System.Windows.Forms.ListBox listBoxCate;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnEnroll;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonAdva;
        private System.Windows.Forms.RadioButton radioButtonInter;
        private System.Windows.Forms.RadioButton radioButtonBegg;
        private System.Windows.Forms.Label lblCate;
        private System.Windows.Forms.Label lblAddiMate;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.CheckBox checkBoxSelfLearnBun;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.GroupBox groupBoxLevel;
    }
}

