using System;

namespace SalaryLibrary{
	public class Staff{
		
		public static double livingAllowance(){
			double livingAllowance = 7800.00;
			return livingAllowance;
		}
		public static double specialAllowance(double basicSalary){
			double specialAllowance = basicSalary*15/100;
			return specialAllowance;
		}
	}
}