using System;

namespace SalaryLibrary{
	public class NonAcademicStaff{
		public static double calculateMCA(double basicSalary){
			double mca = basicSalary*25/100;
			return mca;
		}
	}
}