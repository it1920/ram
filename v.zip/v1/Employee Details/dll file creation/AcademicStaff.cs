using System;

namespace SalaryLibrary{
	public class AcademicStaff{
		
		public static double calculateAcademicAllowance(double basicSalary){
			double academicAllowance = basicSalary*70/100;
			return academicAllowance;
		}
		public static double calculateResearchAllowance(double basicSalary){
			double researchAllowance = basicSalary*15/100;
			return researchAllowance;
		}
	}
}