namespace SalaryLibrary{
	public class SalaryLibraryCls{
		private string staffType;
		private double basicSalary;

		public SalaryLibraryCls(string staffType, double basicSalary){
			this.staffType = staffType;
			this.basicSalary = basicSalary;
		}
		
		public double calAcademicAllow(){
			if(staffType == "Academic"){
				return basicSalary*0.70;
			} else {
				return 0;		
			}
		}
		
		public double calResearchAllow(){
			if(staffType == "Academic"){
				return basicSalary*0.15;
			} else {
				return 0;		
			}
		}
		
		public double calMonthlyCompensAllow(){
			if(staffType == "Academic"){
				return 0;
			} else {
				return basicSalary*0.25;		
			}
		}
		
		public double calSpecialAllow(){
			return basicSalary*0.15;		
		}
		
		public double calTotSalary(){
			return basicSalary+calAcademicAllow()+calResearchAllow()+calMonthlyCompensAllow()+calSpecialAllow()+7800;		
		}


}
}


