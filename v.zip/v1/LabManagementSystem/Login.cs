﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace LabManagementSystem
{
    public partial class Login : Form
    {

        private Registration rg = null;

        public Login()
        {
            InitializeComponent();
        }

        private Boolean validation()
        {
            string username = textBoxUserName.Text;
            string password = textBoxPassword.Text;

            if (String.IsNullOrEmpty(username))
            {
                errorProviderPassword.Clear();
                errorProviderUserName.SetError(textBoxUserName, "This field is cannot be empty!");
                return false;
            }

            else if (String.IsNullOrEmpty(password)){
                errorProviderUserName.Clear();
                errorProviderPassword.SetError(textBoxPassword, "This field is cannot be empty!");
                return false;
            }
            return true;
        }

        private void labelRegister_Click(object sender, EventArgs e)
        {
            if (rg == null || rg.IsDisposed)
            {
                rg = new Registration();
            }
            rg.Show();
            this.Hide();
        }

        private void clearErrors()
        {
            errorProviderUserName.Clear();
            errorProviderPassword.Clear();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Boolean checking = validation();

            if (checking == true)
            {
                clearErrors();
                if (rg == null || rg.IsDisposed)
                {
                    rg = new Registration();
                }
                rg.Show();
                this.Hide();
            }
        }
    }
}
