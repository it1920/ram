﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabManagementSystem
{
    public partial class Home : Form
    {

        private Login lg = null;
        private Registration rg = null;

        public Home()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if(lg == null || lg.IsDisposed)
            {
                lg = new Login();
            }
            lg.Show();
            this.Hide();
        }

        private void buttonCreateNewAccount_Click(object sender, EventArgs e)
        {
            if (rg == null || rg.IsDisposed)
            {
                rg = new Registration();
            }
            rg.Show();
            this.Hide();
        }
    }
}
