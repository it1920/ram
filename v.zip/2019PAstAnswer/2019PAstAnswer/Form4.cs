﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2019PAstAnswer
{
    public partial class Form4 : Form
    {
        Form2 insta;
        public ComboBox combo;
        string btitle, bedition,bfile;
        int bprice=0, bnuc=0, bpage = 0,counter=0;
        Author autho;
        public Form4(Form2 instance)
        {
            InitializeComponent();
            this.insta = instance;
            combo = comboBox1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            insta.Show();
            this.Hide();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            foreach (Author emp in insta.authors)
            {
                if (emp != null)
                    comboBox1.Items.Add(emp.Name);//methana thama null wenne ayye
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            { 
               pictureBox1.Image=Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index=0;
            btitle = textBox1.Text;
            index=comboBox1.SelectedIndex;
            autho= insta.authors[index];
            bedition=textBox2.Text;
            bfile = openFileDialog1.FileName;
            bprice = Convert.ToInt32(numericUpDown1.Value);
            bpage = Convert.ToInt32(numericUpDown2.Value);
            bnuc = Convert.ToInt32(numericUpDown3.Value);
            Book b1 = new Book(btitle, autho, bprice, bedition, bnuc, bpage,bfile);
            insta.books[counter]=b1;
            MessageBox.Show("Book Added Succesfully" + insta.books[0].Title);
            counter++;
        }
        public int Counter { get; set; }
    }
}
