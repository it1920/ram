﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InfiniteLearnFoundation
{
    public partial class Register : Form
    {
        Application application = null;
        public Register()
        {
            InitializeComponent();
        }

        public bool passwordCheck(string password, string conPassword)
        {
            if(password.Length >= 8)
            {
                if (password == conPassword)
                {
                    return true;
                }
                else { 
                    return false; 
                }
            }
            else
            {
                return false;
            }
        }

        public bool emailCheck(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(pattern);

            return regex.IsMatch(email);
            
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (emailCheck(txtEmail.Text) && passwordCheck(txtPassword.Text, txtConfirmPassword.Text) && txtName.Text != "")
            {
                User user = new User(txtName.Text, txtEmail.Text, txtPassword.Text, comboBoxEduLev.SelectedItem.ToString());
                if (application == null || application.IsDisposed)
                {
                    application = new Application(user);
                }
                MessageBox.Show("Successfully Registered");
                application.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Password Does't match \nInvalid Email \nFields Can't be empty \nPassword should have atleast 8 characters");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application application = new Application();
            application.Show();
            this.Hide();
        }
    }
}
