﻿namespace staffManagementSystem
{
    partial class EmployeeDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnLoadImage = new System.Windows.Forms.Button();
            this.pictureBoxPhoto = new System.Windows.Forms.PictureBox();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.radioBtnMarried = new System.Windows.Forms.RadioButton();
            this.radioBtnSingle = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtSex = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtStaffID = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.txtGrossSal = new System.Windows.Forms.TextBox();
            this.txtAcadAllow = new System.Windows.Forms.TextBox();
            this.txtMonthlyCompAllow = new System.Windows.Forms.TextBox();
            this.txtResAllow = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBasicSal = new System.Windows.Forms.TextBox();
            this.txtLivingAllow = new System.Windows.Forms.TextBox();
            this.txtSpecAllow = new System.Windows.Forms.TextBox();
            this.btnEduDet = new System.Windows.Forms.Button();
            this.openFileDialogBrowsePhoto = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnLoadImage);
            this.groupBox1.Controls.Add(this.pictureBoxPhoto);
            this.groupBox1.Controls.Add(this.comboBoxType);
            this.groupBox1.Controls.Add(this.radioBtnMarried);
            this.groupBox1.Controls.Add(this.radioBtnSingle);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtDOB);
            this.groupBox1.Controls.Add(this.txtSex);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.txtStaffID);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.groupBox1.Size = new System.Drawing.Size(1437, 522);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Details";
            // 
            // BtnLoadImage
            // 
            this.BtnLoadImage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.BtnLoadImage.Location = new System.Drawing.Point(1104, 426);
            this.BtnLoadImage.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.BtnLoadImage.Name = "BtnLoadImage";
            this.BtnLoadImage.Size = new System.Drawing.Size(175, 51);
            this.BtnLoadImage.TabIndex = 14;
            this.BtnLoadImage.Text = "Load Image";
            this.BtnLoadImage.UseVisualStyleBackColor = true;
            this.BtnLoadImage.Click += new System.EventHandler(this.BtnLoadImage_Click);
            // 
            // pictureBoxPhoto
            // 
            this.pictureBoxPhoto.Location = new System.Drawing.Point(985, 174);
            this.pictureBoxPhoto.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.pictureBoxPhoto.Name = "pictureBoxPhoto";
            this.pictureBoxPhoto.Size = new System.Drawing.Size(404, 205);
            this.pictureBoxPhoto.TabIndex = 17;
            this.pictureBoxPhoto.TabStop = false;
            // 
            // comboBoxType
            // 
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Items.AddRange(new object[] {
            "Academic",
            "Non-Academic"});
            this.comboBoxType.Location = new System.Drawing.Point(978, 113);
            this.comboBoxType.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(405, 37);
            this.comboBoxType.TabIndex = 16;
            this.comboBoxType.SelectedIndexChanged += new System.EventHandler(this.comboBoxType_SelectedIndexChanged);
            // 
            // radioBtnMarried
            // 
            this.radioBtnMarried.AutoSize = true;
            this.radioBtnMarried.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioBtnMarried.Location = new System.Drawing.Point(1190, 60);
            this.radioBtnMarried.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.radioBtnMarried.Name = "radioBtnMarried";
            this.radioBtnMarried.Size = new System.Drawing.Size(156, 38);
            this.radioBtnMarried.TabIndex = 15;
            this.radioBtnMarried.Text = "Married";
            this.radioBtnMarried.UseVisualStyleBackColor = true;
            // 
            // radioBtnSingle
            // 
            this.radioBtnSingle.AutoSize = true;
            this.radioBtnSingle.Checked = true;
            this.radioBtnSingle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioBtnSingle.Location = new System.Drawing.Point(978, 60);
            this.radioBtnSingle.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.radioBtnSingle.Name = "radioBtnSingle";
            this.radioBtnSingle.Size = new System.Drawing.Size(139, 38);
            this.radioBtnSingle.TabIndex = 15;
            this.radioBtnSingle.TabStop = true;
            this.radioBtnSingle.Text = "Single";
            this.radioBtnSingle.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(868, 181);
            this.label17.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 29);
            this.label17.TabIndex = 14;
            this.label17.Text = "Photo :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(877, 123);
            this.label16.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 29);
            this.label16.TabIndex = 14;
            this.label16.Text = "Type :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(812, 65);
            this.label15.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(157, 29);
            this.label15.TabIndex = 14;
            this.label15.Text = "Civil Status :";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(245, 297);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(345, 176);
            this.txtAddress.TabIndex = 12;
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(245, 234);
            this.txtDOB.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(345, 35);
            this.txtDOB.TabIndex = 12;
            // 
            // txtSex
            // 
            this.txtSex.Location = new System.Drawing.Point(245, 174);
            this.txtSex.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtSex.Name = "txtSex";
            this.txtSex.Size = new System.Drawing.Size(345, 35);
            this.txtSex.TabIndex = 12;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(245, 116);
            this.txtName.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(345, 35);
            this.txtName.TabIndex = 12;
            // 
            // txtStaffID
            // 
            this.txtStaffID.Location = new System.Drawing.Point(245, 58);
            this.txtStaffID.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Size = new System.Drawing.Size(345, 35);
            this.txtStaffID.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(63, 241);
            this.label12.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 29);
            this.label12.TabIndex = 11;
            this.label12.Text = "Date of Birth :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(135, 123);
            this.label11.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 29);
            this.label11.TabIndex = 10;
            this.label11.Text = "Name :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(159, 181);
            this.label10.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 29);
            this.label10.TabIndex = 9;
            this.label10.Text = "Sex :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 303);
            this.label8.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 29);
            this.label8.TabIndex = 7;
            this.label8.Text = "Address :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "StaffID :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCal);
            this.groupBox2.Controls.Add(this.txtGrossSal);
            this.groupBox2.Controls.Add(this.txtAcadAllow);
            this.groupBox2.Controls.Add(this.txtMonthlyCompAllow);
            this.groupBox2.Controls.Add(this.txtResAllow);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtBasicSal);
            this.groupBox2.Controls.Add(this.txtLivingAllow);
            this.groupBox2.Controls.Add(this.txtSpecAllow);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 535);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.groupBox2.Size = new System.Drawing.Size(1437, 471);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Salary Details";
            // 
            // btnCal
            // 
            this.btnCal.ForeColor = System.Drawing.Color.Red;
            this.btnCal.Location = new System.Drawing.Point(1034, 174);
            this.btnCal.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(324, 177);
            this.btnCal.TabIndex = 13;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // txtGrossSal
            // 
            this.txtGrossSal.Location = new System.Drawing.Point(530, 413);
            this.txtGrossSal.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtGrossSal.Name = "txtGrossSal";
            this.txtGrossSal.Size = new System.Drawing.Size(345, 35);
            this.txtGrossSal.TabIndex = 12;
            // 
            // txtAcadAllow
            // 
            this.txtAcadAllow.Location = new System.Drawing.Point(415, 290);
            this.txtAcadAllow.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtAcadAllow.Name = "txtAcadAllow";
            this.txtAcadAllow.Size = new System.Drawing.Size(345, 35);
            this.txtAcadAllow.TabIndex = 12;
            // 
            // txtMonthlyCompAllow
            // 
            this.txtMonthlyCompAllow.Location = new System.Drawing.Point(415, 348);
            this.txtMonthlyCompAllow.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtMonthlyCompAllow.Name = "txtMonthlyCompAllow";
            this.txtMonthlyCompAllow.Size = new System.Drawing.Size(345, 35);
            this.txtMonthlyCompAllow.TabIndex = 12;
            // 
            // txtResAllow
            // 
            this.txtResAllow.Location = new System.Drawing.Point(415, 232);
            this.txtResAllow.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtResAllow.Name = "txtResAllow";
            this.txtResAllow.Size = new System.Drawing.Size(345, 35);
            this.txtResAllow.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(236, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Basic Salary :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(348, 419);
            this.label7.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(176, 29);
            this.label7.TabIndex = 11;
            this.label7.Text = "Gross Salary :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(135, 297);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(268, 29);
            this.label9.TabIndex = 11;
            this.label9.Text = "Academic Allowance :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(168, 181);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(242, 29);
            this.label3.TabIndex = 9;
            this.label3.Text = "Special Allowance :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 355);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(404, 29);
            this.label6.TabIndex = 11;
            this.label6.Text = "Monthly Comensatory Allowance :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(184, 123);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 29);
            this.label4.TabIndex = 10;
            this.label4.Text = "Living Allowance :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(142, 239);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(265, 29);
            this.label5.TabIndex = 11;
            this.label5.Text = "Research Allowance :";
            // 
            // txtBasicSal
            // 
            this.txtBasicSal.Location = new System.Drawing.Point(415, 58);
            this.txtBasicSal.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtBasicSal.Name = "txtBasicSal";
            this.txtBasicSal.Size = new System.Drawing.Size(345, 35);
            this.txtBasicSal.TabIndex = 12;
            // 
            // txtLivingAllow
            // 
            this.txtLivingAllow.Location = new System.Drawing.Point(415, 116);
            this.txtLivingAllow.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtLivingAllow.Name = "txtLivingAllow";
            this.txtLivingAllow.Size = new System.Drawing.Size(345, 35);
            this.txtLivingAllow.TabIndex = 12;
            // 
            // txtSpecAllow
            // 
            this.txtSpecAllow.Location = new System.Drawing.Point(415, 174);
            this.txtSpecAllow.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.txtSpecAllow.Name = "txtSpecAllow";
            this.txtSpecAllow.Size = new System.Drawing.Size(345, 35);
            this.txtSpecAllow.TabIndex = 12;
            // 
            // btnEduDet
            // 
            this.btnEduDet.Location = new System.Drawing.Point(1065, 1020);
            this.btnEduDet.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.btnEduDet.Name = "btnEduDet";
            this.btnEduDet.Size = new System.Drawing.Size(324, 51);
            this.btnEduDet.TabIndex = 14;
            this.btnEduDet.Text = "Educational Details";
            this.btnEduDet.UseVisualStyleBackColor = true;
            this.btnEduDet.Click += new System.EventHandler(this.btnEduDet_Click);
            // 
            // openFileDialogBrowsePhoto
            // 
            this.openFileDialogBrowsePhoto.FileName = "openFileDialogBrowsePhoto";
            // 
            // EmployeeDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1435, 1095);
            this.Controls.Add(this.btnEduDet);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.Name = "EmployeeDetails";
            this.Text = "Employee Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnLoadImage;
        private System.Windows.Forms.PictureBox pictureBoxPhoto;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.RadioButton radioBtnMarried;
        private System.Windows.Forms.RadioButton radioBtnSingle;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtSex;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtStaffID;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtResAllow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBasicSal;
        private System.Windows.Forms.TextBox txtLivingAllow;
        private System.Windows.Forms.TextBox txtSpecAllow;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.TextBox txtGrossSal;
        private System.Windows.Forms.TextBox txtMonthlyCompAllow;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnEduDet;
        private System.Windows.Forms.TextBox txtAcadAllow;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.OpenFileDialog openFileDialogBrowsePhoto;
    }
}

