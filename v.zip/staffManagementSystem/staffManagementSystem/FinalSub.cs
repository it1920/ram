﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace staffManagementSystem
{
    public partial class FinalSub : Form
    {
        public FinalSub()
        {
            InitializeComponent();
        }

        EducationalDet educationalDet = null;
        EmployeeDetails employeeDetails = null;

        public FinalSub(EducationalDet eduDetObj, EmployeeDetails empDetObj)
        {
            educationalDet = eduDetObj;
            employeeDetails = empDetObj;
            InitializeComponent();
            lblStaffID.Text = employeeDetails.getStaffId() ;
            lblName.Text = employeeDetails.getName();
            lblSex.Text = employeeDetails.getSex();
            lblDOB.Text = employeeDetails.getDOB();
            lblAddr.Text = employeeDetails.getAddr();
            lblCivil.Text = employeeDetails.getCivil();
            lblStaffType.Text = employeeDetails.getType();
            lblBasicSal.Text = employeeDetails.getBasic();
            lblLivAllow.Text = employeeDetails.getLiving();
            lblSpecAllow.Text = employeeDetails.getSpecial();
            lblAcadAllow.Text = employeeDetails.getAcad();
            lblResAllow.Text = employeeDetails.getResearch();
            lblGrossSal.Text = employeeDetails.getGross();
            lblUni.Text = educationalDet.getUni();
            lblStream.Text = educationalDet.getStream();
            lblDeg.Text = educationalDet.getDegree();
            lblYear.Text = educationalDet.getYear();
            lblClass.Text = educationalDet.getClass();
            lblMaster.Text = educationalDet.getMaster();
            lblMPhil.Text = educationalDet.getMphil();
            lblPhd.Text = educationalDet.getPhd();

        }
    }
}
