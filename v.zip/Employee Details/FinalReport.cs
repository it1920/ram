﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Details
{
    public partial class FinalReport : Form
    {
        public FinalReport()
        {
            InitializeComponent();
        }

        EducationalDetails eduDetails = null;
        EmployeeDetails empDetails = null;

        public FinalReport(EmployeeDetails empDet, EducationalDetails eduDet)
        {
            eduDetails = eduDet;
            empDetails = empDet;
            InitializeComponent();

            labelStaffID.Text = empDetails.getStaffId();
            labelName.Text = empDetails.getName();
            labelSex.Text = empDetails.getSex();
            labelDOB.Text = empDetails.getDOB();
            labelAddress.Text = empDetails.getAddress();
            labelCivilStatus.Text = empDetails.getCivilStatus();
            labelType.Text = empDetails.getType().ToString();
            labelBasicSalary.Text = empDetails.getBasicSalary();
            labelLA.Text = empDetails.getLivingAllowance();
            labelSA.Text = empDetails.getSpecialAllowance();
            labelAA.Text = empDetails.getAcademicAllowance();
            labelRA.Text = empDetails.getResearchAllowance();
            labelMCA.Text = empDetails.getMCA().ToString();
            labelGrossSalary.Text = empDetails.getGrossSalary();
            labelAL.Text = eduDetails.getStream();
            labelUni.Text = eduDetails.getUniversity();
            labelYear.Text = eduDetails.getYear();
            labelDegree.Text = eduDetails.getDegree();
            labelClass.Text = eduDetails.getClass();
            labelPostDeg.Text = eduDetails.getPostgraduateDet();
        }
    }
}
