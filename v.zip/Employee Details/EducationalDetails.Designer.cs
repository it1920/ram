﻿namespace Employee_Details
{
    partial class EducationalDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxStream = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxClass = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxDegree = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxYear = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxUniversity = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBoxPhD = new System.Windows.Forms.CheckBox();
            this.checkBoxMphil = new System.Windows.Forms.CheckBox();
            this.checkBoxMasters = new System.Windows.Forms.CheckBox();
            this.buttoneFinalReport = new System.Windows.Forms.Button();
            this.buttonEmployeeDetails = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxStream);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(712, 101);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Advanced Level Details";
            // 
            // comboBoxStream
            // 
            this.comboBoxStream.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxStream.FormattingEnabled = true;
            this.comboBoxStream.Items.AddRange(new object[] {
            "Maths",
            "Biology",
            "Commerce",
            "Arts",
            "Technology"});
            this.comboBoxStream.Location = new System.Drawing.Point(233, 44);
            this.comboBoxStream.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxStream.Name = "comboBoxStream";
            this.comboBoxStream.Size = new System.Drawing.Size(212, 28);
            this.comboBoxStream.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(144, 44);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Stream :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxClass);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.comboBoxDegree);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.comboBoxYear);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.comboBoxUniversity);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(16, 123);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(712, 143);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Undergraduate Degree Details";
            // 
            // comboBoxClass
            // 
            this.comboBoxClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxClass.FormattingEnabled = true;
            this.comboBoxClass.Items.AddRange(new object[] {
            "First class",
            "Second class upper",
            "Second class lower"});
            this.comboBoxClass.Location = new System.Drawing.Point(504, 91);
            this.comboBoxClass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxClass.Name = "comboBoxClass";
            this.comboBoxClass.Size = new System.Drawing.Size(187, 28);
            this.comboBoxClass.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(440, 95);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Class :";
            // 
            // comboBoxDegree
            // 
            this.comboBoxDegree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDegree.FormattingEnabled = true;
            this.comboBoxDegree.Items.AddRange(new object[] {
            "BSc in Information Technology",
            "BSc(hons) in Information Technology",
            "BSc in Software Engineering",
            "BSc(hons) in Software Engineering"});
            this.comboBoxDegree.Location = new System.Drawing.Point(137, 91);
            this.comboBoxDegree.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxDegree.Name = "comboBoxDegree";
            this.comboBoxDegree.Size = new System.Drawing.Size(283, 28);
            this.comboBoxDegree.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(52, 95);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 20;
            this.label4.Text = "Degree :";
            // 
            // comboBoxYear
            // 
            this.comboBoxYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxYear.FormattingEnabled = true;
            this.comboBoxYear.Items.AddRange(new object[] {
            "16/17",
            "18/19",
            "20/21",
            "22/23"});
            this.comboBoxYear.Location = new System.Drawing.Point(504, 44);
            this.comboBoxYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxYear.Name = "comboBoxYear";
            this.comboBoxYear.Size = new System.Drawing.Size(187, 28);
            this.comboBoxYear.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(445, 48);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Year :";
            // 
            // comboBoxUniversity
            // 
            this.comboBoxUniversity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxUniversity.FormattingEnabled = true;
            this.comboBoxUniversity.Items.AddRange(new object[] {
            "University of Colombo",
            "University of Jaffna",
            "University of Jayawardanapura",
            "University of Moratuwa",
            "University of Peradeniya",
            "University of Ruhuna",
            "University of Sabaragamuwa",
            "University of South Eastern",
            "University of Uva Wellassa",
            "University of Vavuniya"});
            this.comboBoxUniversity.Location = new System.Drawing.Point(137, 44);
            this.comboBoxUniversity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxUniversity.Name = "comboBoxUniversity";
            this.comboBoxUniversity.Size = new System.Drawing.Size(283, 28);
            this.comboBoxUniversity.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 48);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "University :";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBoxPhD);
            this.groupBox3.Controls.Add(this.checkBoxMphil);
            this.groupBox3.Controls.Add(this.checkBoxMasters);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(16, 273);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(712, 122);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Postgraduate Degree Details";
            // 
            // checkBoxPhD
            // 
            this.checkBoxPhD.AutoSize = true;
            this.checkBoxPhD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPhD.Location = new System.Drawing.Point(441, 57);
            this.checkBoxPhD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxPhD.Name = "checkBoxPhD";
            this.checkBoxPhD.Size = new System.Drawing.Size(64, 24);
            this.checkBoxPhD.TabIndex = 3;
            this.checkBoxPhD.Text = "PhD";
            this.checkBoxPhD.UseVisualStyleBackColor = true;
            // 
            // checkBoxMphil
            // 
            this.checkBoxMphil.AutoSize = true;
            this.checkBoxMphil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxMphil.Location = new System.Drawing.Point(319, 57);
            this.checkBoxMphil.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxMphil.Name = "checkBoxMphil";
            this.checkBoxMphil.Size = new System.Drawing.Size(71, 24);
            this.checkBoxMphil.TabIndex = 2;
            this.checkBoxMphil.Text = "Mphil";
            this.checkBoxMphil.UseVisualStyleBackColor = true;
            // 
            // checkBoxMasters
            // 
            this.checkBoxMasters.AutoSize = true;
            this.checkBoxMasters.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxMasters.Location = new System.Drawing.Point(176, 57);
            this.checkBoxMasters.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxMasters.Name = "checkBoxMasters";
            this.checkBoxMasters.Size = new System.Drawing.Size(92, 24);
            this.checkBoxMasters.TabIndex = 1;
            this.checkBoxMasters.Text = "Masters";
            this.checkBoxMasters.UseVisualStyleBackColor = true;
            // 
            // buttoneFinalReport
            // 
            this.buttoneFinalReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoneFinalReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttoneFinalReport.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttoneFinalReport.Location = new System.Drawing.Point(457, 402);
            this.buttoneFinalReport.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttoneFinalReport.Name = "buttoneFinalReport";
            this.buttoneFinalReport.Size = new System.Drawing.Size(165, 43);
            this.buttoneFinalReport.TabIndex = 25;
            this.buttoneFinalReport.Text = "Final Report";
            this.buttoneFinalReport.UseVisualStyleBackColor = true;
            this.buttoneFinalReport.Click += new System.EventHandler(this.buttoneFinalReport_Click);
            // 
            // buttonEmployeeDetails
            // 
            this.buttonEmployeeDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEmployeeDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEmployeeDetails.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonEmployeeDetails.Location = new System.Drawing.Point(128, 402);
            this.buttonEmployeeDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonEmployeeDetails.Name = "buttonEmployeeDetails";
            this.buttonEmployeeDetails.Size = new System.Drawing.Size(228, 43);
            this.buttonEmployeeDetails.TabIndex = 26;
            this.buttonEmployeeDetails.Text = "Employee Details";
            this.buttonEmployeeDetails.UseVisualStyleBackColor = true;
            this.buttonEmployeeDetails.Click += new System.EventHandler(this.buttonEmployeeDetails_Click);
            // 
            // EducationalDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 459);
            this.Controls.Add(this.buttonEmployeeDetails);
            this.Controls.Add(this.buttoneFinalReport);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "EducationalDetails";
            this.Text = "Educational Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxStream;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxYear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxUniversity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxClass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxDegree;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBoxPhD;
        private System.Windows.Forms.CheckBox checkBoxMphil;
        private System.Windows.Forms.CheckBox checkBoxMasters;
        private System.Windows.Forms.Button buttoneFinalReport;
        private System.Windows.Forms.Button buttonEmployeeDetails;
    }
}