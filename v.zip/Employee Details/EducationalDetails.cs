﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Details
{
    public partial class EducationalDetails : Form
    {
        public EducationalDetails()
        {
            InitializeComponent();
        }

        EmployeeDetails empDetails = null;
        FinalReport finalReport = null;

        public EducationalDetails(EmployeeDetails empDet)
        {
            empDetails = empDet;
            InitializeComponent();
        }



        public EducationalDetails(FinalReport finalReport)
        {
            finalReport = finalReport;
            InitializeComponent();
        }

        private void buttonEmployeeDetails_Click(object sender, EventArgs e)
        {
            if(empDetails == null || empDetails.IsDisposed)
            {
                empDetails = new EmployeeDetails(this);
            }

            empDetails.Show();
            this.Hide();
        }

        private void buttoneFinalReport_Click(object sender, EventArgs e)
        {
            if(finalReport == null || finalReport.IsDisposed)
            {
                finalReport = new FinalReport(empDetails, this);
            }

            finalReport.Show();
            this.Hide();
        }

        public string getStream()
        {
            return comboBoxStream.Text;
        }

        public string getUniversity()
        {
            return comboBoxUniversity.Text;
        }

        public string getYear()
        {
            return comboBoxYear.Text;
        }

        public string getDegree()
        {
            return comboBoxDegree.Text;
        }

        public string getClass()
        {
            return comboBoxClass.Text;
        }

        public string getPostgraduateDet()
        {
            string degree = "";

            if(checkBoxMasters.Checked)
            {
                degree += checkBoxMasters.Text + ", ";
            }
            if (checkBoxMphil.Checked)
            {
                degree += checkBoxMphil.Text + ", ";
            }
            if (checkBoxPhD.Checked)
            {
                degree += checkBoxPhD.Text;
            }

            return degree;
        }
    }
}
