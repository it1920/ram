﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalaryLibrary;

namespace Employee_Details
{
    public partial class EmployeeDetails : Form
    {

        public EmployeeDetails()
        {
            InitializeComponent();
        }

        private EducationalDetails eduDetails = null;

        public EmployeeDetails(EducationalDetails eduDet)
        {
            eduDetails = eduDet;
            InitializeComponent();
        }

        private void buttoneEducationalDetails_Click(object sender, EventArgs e)
        {
            if(eduDetails == null || eduDetails.IsDisposed)
            {
                eduDetails = new EducationalDetails(this);
            }

            eduDetails.Show();
            this.Hide();

        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double basicSalary = Convert.ToDouble(this.textBoxBasicSalary.Text);
            double LA, SA, AA = 0, RA = 0, MCA = 0;

            LA = Staff.livingAllowance();
            this.textBoxLivingAllowance.Text = LA.ToString();

            SA = Staff.specialAllowance(basicSalary);
            this.textBoxSpecialAllowance.Text = SA.ToString();

            if (comboBoxType.SelectedItem.ToString() == "Academic")
            {
                AA = AcademicStaff.calculateAcademicAllowance(basicSalary);
                this.textBoxAcademicAllowance.Text = AA.ToString();

                RA = AcademicStaff.calculateResearchAllowance(basicSalary);
                this.textBoxResearchAllowance.Text = RA.ToString();

                this.textBoxMCA.Text = MCA.ToString();
            }
            else
            {
                MCA = NonAcademicStaff.calculateMCA(basicSalary);
                this.textBoxMCA.Text = MCA.ToString();
                this.textBoxAcademicAllowance.Text = AA.ToString();
                this.textBoxResearchAllowance.Text = RA.ToString();
            }

            double grossSalary = basicSalary + LA + SA + AA + RA + MCA;

            this.textBoxGrossSalary.Text = grossSalary.ToString();
        }

        private void buttonLoadImage_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialogLoadImage.ShowDialog();

            if(result.Equals(DialogResult.OK))
            {
                string filename = openFileDialogLoadImage.FileName;
                pictureBoxDP.Image = Image.FromFile(filename);
            }
        }

        public string getStaffId()
        {
            return textBoxStaffID.Text;
        }
        public string getName()
        {
            return textBoxName.Text;
        }

        public string getSex()
        {
            String sex = "";

            if (radioButtonMale.Checked)
            {
                sex = radioButtonMale.Text;
            }
            else if (radioButtonFemale.Checked)
            {
                sex = radioButtonFemale.Text;
            }

            return sex;
        }

        public string getDOB()
        {
            return dateTimePickerDOB.Text;
        }

        public string getAddress()
        {
            return textBoxAddress.Text;
        }

        public string getCivilStatus()
        {
            string civilStatus = "";

            if(radioButtonSingle.Checked)
            {
                civilStatus = radioButtonSingle.Text;
            }
            else if (radioButtonMarried.Checked)
            {
                civilStatus = radioButtonMarried.Text;
            }

            return civilStatus;
        }

        public string getType()
        {
            return comboBoxType.Text;
        }

        public string getBasicSalary()
        {
            return textBoxBasicSalary.Text;
        }

        public string getLivingAllowance()
        {
            return textBoxLivingAllowance.Text;
        }

        public string getSpecialAllowance()
        {
            return textBoxSpecialAllowance.Text;
        }

        public string getResearchAllowance()
        {
            return textBoxResearchAllowance.Text;
        }

        public string getAcademicAllowance()
        {
            return textBoxAcademicAllowance.Text;
        }

        public string getMCA()
        {
            return textBoxMCA.Text;
        }

        public string getGrossSalary()
        {
            return textBoxGrossSalary.Text;
        }

    }
}
