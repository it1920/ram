﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using University;

namespace Paspaper2024
{
   
    public partial class Dashboard : Form
    {
        Admin admin;
        User user;

        
        private Course[] courses = new Course[10];
        public int coursecount = -1;

        
        private Student[] students = new Student[10];
        public int studentcount = -1;
        public Dashboard()
        {
            InitializeComponent();
           

        }
        public Course[] Courses
        {
            get { return courses; }
            set { courses = value; }
        }

        public Student[] Students
        {
            get { return students; }
            set { students = value; }
        }
        public Dashboard(Admin admin,bool state)
        {
            InitializeComponent();
            this.admin = admin;
            button1.Visible = button2.Visible = button3.Visible = state;
        }

        public Dashboard(User user,bool state)
        {
            InitializeComponent();
            this.user = user;
            button2.Visible = state;

        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursecount++;

            AddCourse ac = new AddCourse(this);
            ac.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            ViewStudent vs = new ViewStudent(this);
            vs.ShowDialog();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            studentcount++;
			
            AddStudent asd = new AddStudent(this);
            asd.Show();
            this.Hide();

        }
    }
}
