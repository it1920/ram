﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2019PAstAnswer
{
    public  class Book
    {
        private string title;
        private Author author;
        private int price;
        private string edition;
        private int nuc;
        private int pages;
        private string file;
        public Book() { }
        public Book(string title,Author author,int price,string edition,int nuc,int pages,string file) 
        {
            this.title = title;
            this.author = author;
            this.price = price;
            this.edition = edition;
            this.nuc = nuc;
            this.pages = pages;
            this.file = file;
            
        }
        public string Title
        {
            get { return this.title; }
            set { this.title = value; }
        }
        public Author Author
        {
            get { return this.author; }
            set { this.author = value; }
        }
        public int Price
        { get { return this.price; }
        set { this.price = value; } 
        }
        public String Edition
        { get { return this.edition; }
            set { this.edition = value; }
        }
        public int Nuc
        {
            get { return this.nuc; }
            set
            {
                this.nuc = value;
            }
        }
        public int Pages
        {
            get { return this.pages; }
            set
            {
                this.pages = value;
            }
        }
        public string File
        {
            get
            {
                return this.file;
            }
            set
            {
                this.file = value;
            }
        }

    }
}
