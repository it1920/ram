import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class translation extends JFrame implements MouseListener
{
	Graphics g;
	int x1,x2,y1,y2,dx,dy;
	 
	translation()
	{
		super("translation");
		setSize(500,500);
		addMouseListener(this);	
		setVisible(true);
		g=getGraphics();
		g.setColor(Color.red);
	}
	public static void main(String a[])
	{
		translation b=new translation();
		b.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}
	public void translateLine(int x1,int y1,int x2,int y2,int dx,int dy)
	{
		g.setColor(Color.red);
		g.drawLine(x1,y1,x2,y2);
		g.setColor(Color.blue);
		int x1new,x2new ,y1new,y2new;
		x1new=x1+dx;
		x2new=x2+dx;
		y1new=y1+dy;
		y2new=y2+dy;
		g.drawLine(x1new,y1new,x2new,y2new);
		
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me)
	{
		 x1=me.getX();
		 y1=me.getY();
	}
	public void mouseReleased(MouseEvent me)
	{
		x2=me.getX();
		y2=me.getY();
		g.drawLine(x1,y1,x1,y1);
		translatepoint(50,50);
		translateLine(x1,y1,x2,y2,100,100);
	}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}	
	public void mouseDragged(MouseEvent me){}
	public void mouseMove(MouseEvent me){}
	public void translatepoint(int x11,int y11)
	{
		 int xnew=x1+x11;
		 int ynew=y1+y11;
		 g.setColor(Color.blue);
		 g.drawLine(xnew,ynew,xnew,ynew);
	
	}
}