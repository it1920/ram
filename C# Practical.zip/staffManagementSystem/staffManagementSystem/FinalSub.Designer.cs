﻿namespace staffManagementSystem
{
    partial class FinalSub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblMPhil = new System.Windows.Forms.Label();
            this.lblPhd = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblMaster = new System.Windows.Forms.Label();
            this.lblStaffType = new System.Windows.Forms.Label();
            this.lblAddr = new System.Windows.Forms.Label();
            this.lblCivil = new System.Windows.Forms.Label();
            this.lblSex = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.lblResAllow = new System.Windows.Forms.Label();
            this.lblGrossSal = new System.Windows.Forms.Label();
            this.lblSpecAllow = new System.Windows.Forms.Label();
            this.lblAcadAllow = new System.Windows.Forms.Label();
            this.lblLivAllow = new System.Windows.Forms.Label();
            this.lblBasicSal = new System.Windows.Forms.Label();
            this.lblStream = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblDeg = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblUni = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(24, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Personal Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(140, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Staff ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(140, 86);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(140, 136);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "Date of Birth";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(140, 111);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 25);
            this.label5.TabIndex = 3;
            this.label5.Text = "Sex";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(140, 186);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Civil Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(140, 161);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(140, 211);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Staff Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label10.Location = new System.Drawing.Point(140, 398);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(176, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Research Details";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label11.Location = new System.Drawing.Point(140, 423);
            this.label11.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 25);
            this.label11.TabIndex = 12;
            this.label11.Text = "Gross Salary";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label12.Location = new System.Drawing.Point(140, 348);
            this.label12.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(187, 25);
            this.label12.TabIndex = 11;
            this.label12.Text = "Special Allowance";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label13.Location = new System.Drawing.Point(140, 373);
            this.label13.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(210, 25);
            this.label13.TabIndex = 10;
            this.label13.Text = "Academic Allowance";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label14.Location = new System.Drawing.Point(140, 323);
            this.label14.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(173, 25);
            this.label14.TabIndex = 9;
            this.label14.Text = "Living Allowance";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label15.Location = new System.Drawing.Point(140, 298);
            this.label15.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 25);
            this.label15.TabIndex = 7;
            this.label15.Text = "Basic salary";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(24, 253);
            this.label16.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(145, 25);
            this.label16.TabIndex = 8;
            this.label16.Text = "Salary Details";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(202, 611);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 25);
            this.label9.TabIndex = 20;
            this.label9.Text = "Degree";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(202, 636);
            this.label17.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 25);
            this.label17.TabIndex = 19;
            this.label17.Text = "Year";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Green;
            this.label18.Location = new System.Drawing.Point(140, 561);
            this.label18.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(165, 25);
            this.label18.TabIndex = 18;
            this.label18.Text = "Under Graduate";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(202, 586);
            this.label19.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 25);
            this.label19.TabIndex = 17;
            this.label19.Text = "University";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(202, 536);
            this.label20.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 25);
            this.label20.TabIndex = 16;
            this.label20.Text = "Stream";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Green;
            this.label21.Location = new System.Drawing.Point(140, 511);
            this.label21.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(154, 25);
            this.label21.TabIndex = 14;
            this.label21.Text = "Advance Level";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(24, 467);
            this.label22.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(197, 25);
            this.label22.TabIndex = 15;
            this.label22.Text = "Educational Details";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(202, 661);
            this.label23.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 25);
            this.label23.TabIndex = 21;
            this.label23.Text = "Class";
            // 
            // lblMPhil
            // 
            this.lblMPhil.AutoSize = true;
            this.lblMPhil.Location = new System.Drawing.Point(202, 739);
            this.lblMPhil.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMPhil.Name = "lblMPhil";
            this.lblMPhil.Size = new System.Drawing.Size(0, 25);
            this.lblMPhil.TabIndex = 25;
            // 
            // lblPhd
            // 
            this.lblPhd.AutoSize = true;
            this.lblPhd.Location = new System.Drawing.Point(202, 764);
            this.lblPhd.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPhd.Name = "lblPhd";
            this.lblPhd.Size = new System.Drawing.Size(0, 25);
            this.lblPhd.TabIndex = 24;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Green;
            this.label27.Location = new System.Drawing.Point(140, 689);
            this.label27.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(150, 25);
            this.label27.TabIndex = 23;
            this.label27.Text = "Post Graduate";
            // 
            // lblMaster
            // 
            this.lblMaster.AutoSize = true;
            this.lblMaster.Location = new System.Drawing.Point(202, 714);
            this.lblMaster.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMaster.Name = "lblMaster";
            this.lblMaster.Size = new System.Drawing.Size(0, 25);
            this.lblMaster.TabIndex = 22;
            // 
            // lblStaffType
            // 
            this.lblStaffType.AutoSize = true;
            this.lblStaffType.Location = new System.Drawing.Point(351, 211);
            this.lblStaffType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStaffType.Name = "lblStaffType";
            this.lblStaffType.Size = new System.Drawing.Size(0, 25);
            this.lblStaffType.TabIndex = 32;
            // 
            // lblAddr
            // 
            this.lblAddr.AutoSize = true;
            this.lblAddr.Location = new System.Drawing.Point(351, 161);
            this.lblAddr.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAddr.Name = "lblAddr";
            this.lblAddr.Size = new System.Drawing.Size(0, 25);
            this.lblAddr.TabIndex = 31;
            // 
            // lblCivil
            // 
            this.lblCivil.AutoSize = true;
            this.lblCivil.Location = new System.Drawing.Point(351, 186);
            this.lblCivil.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCivil.Name = "lblCivil";
            this.lblCivil.Size = new System.Drawing.Size(0, 25);
            this.lblCivil.TabIndex = 30;
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Location = new System.Drawing.Point(351, 111);
            this.lblSex.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(0, 25);
            this.lblSex.TabIndex = 29;
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(351, 136);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(0, 25);
            this.lblDOB.TabIndex = 28;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(351, 86);
            this.lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 25);
            this.lblName.TabIndex = 27;
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Location = new System.Drawing.Point(351, 61);
            this.lblStaffID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(0, 25);
            this.lblStaffID.TabIndex = 26;
            // 
            // lblResAllow
            // 
            this.lblResAllow.AutoSize = true;
            this.lblResAllow.Location = new System.Drawing.Point(351, 398);
            this.lblResAllow.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblResAllow.Name = "lblResAllow";
            this.lblResAllow.Size = new System.Drawing.Size(0, 25);
            this.lblResAllow.TabIndex = 38;
            // 
            // lblGrossSal
            // 
            this.lblGrossSal.AutoSize = true;
            this.lblGrossSal.Location = new System.Drawing.Point(351, 423);
            this.lblGrossSal.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblGrossSal.Name = "lblGrossSal";
            this.lblGrossSal.Size = new System.Drawing.Size(0, 25);
            this.lblGrossSal.TabIndex = 37;
            // 
            // lblSpecAllow
            // 
            this.lblSpecAllow.AutoSize = true;
            this.lblSpecAllow.Location = new System.Drawing.Point(351, 348);
            this.lblSpecAllow.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSpecAllow.Name = "lblSpecAllow";
            this.lblSpecAllow.Size = new System.Drawing.Size(0, 25);
            this.lblSpecAllow.TabIndex = 36;
            // 
            // lblAcadAllow
            // 
            this.lblAcadAllow.AutoSize = true;
            this.lblAcadAllow.Location = new System.Drawing.Point(351, 373);
            this.lblAcadAllow.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAcadAllow.Name = "lblAcadAllow";
            this.lblAcadAllow.Size = new System.Drawing.Size(0, 25);
            this.lblAcadAllow.TabIndex = 35;
            // 
            // lblLivAllow
            // 
            this.lblLivAllow.AutoSize = true;
            this.lblLivAllow.Location = new System.Drawing.Point(351, 323);
            this.lblLivAllow.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblLivAllow.Name = "lblLivAllow";
            this.lblLivAllow.Size = new System.Drawing.Size(0, 25);
            this.lblLivAllow.TabIndex = 34;
            // 
            // lblBasicSal
            // 
            this.lblBasicSal.AutoSize = true;
            this.lblBasicSal.Location = new System.Drawing.Point(351, 298);
            this.lblBasicSal.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblBasicSal.Name = "lblBasicSal";
            this.lblBasicSal.Size = new System.Drawing.Size(0, 25);
            this.lblBasicSal.TabIndex = 33;
            // 
            // lblStream
            // 
            this.lblStream.AutoSize = true;
            this.lblStream.Location = new System.Drawing.Point(380, 536);
            this.lblStream.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStream.Name = "lblStream";
            this.lblStream.Size = new System.Drawing.Size(0, 25);
            this.lblStream.TabIndex = 39;
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(380, 661);
            this.lblClass.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(0, 25);
            this.lblClass.TabIndex = 43;
            // 
            // lblDeg
            // 
            this.lblDeg.AutoSize = true;
            this.lblDeg.Location = new System.Drawing.Point(380, 611);
            this.lblDeg.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDeg.Name = "lblDeg";
            this.lblDeg.Size = new System.Drawing.Size(0, 25);
            this.lblDeg.TabIndex = 42;
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(380, 636);
            this.lblYear.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(0, 25);
            this.lblYear.TabIndex = 41;
            // 
            // lblUni
            // 
            this.lblUni.AutoSize = true;
            this.lblUni.Location = new System.Drawing.Point(380, 586);
            this.lblUni.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblUni.Name = "lblUni";
            this.lblUni.Size = new System.Drawing.Size(0, 25);
            this.lblUni.TabIndex = 40;
            // 
            // FinalSub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 866);
            this.Controls.Add(this.lblClass);
            this.Controls.Add(this.lblDeg);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.lblUni);
            this.Controls.Add(this.lblStream);
            this.Controls.Add(this.lblResAllow);
            this.Controls.Add(this.lblGrossSal);
            this.Controls.Add(this.lblSpecAllow);
            this.Controls.Add(this.lblAcadAllow);
            this.Controls.Add(this.lblLivAllow);
            this.Controls.Add(this.lblBasicSal);
            this.Controls.Add(this.lblStaffType);
            this.Controls.Add(this.lblAddr);
            this.Controls.Add(this.lblCivil);
            this.Controls.Add(this.lblSex);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.lblMPhil);
            this.Controls.Add(this.lblPhd);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.lblMaster);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FinalSub";
            this.Text = "FinalSub";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblMPhil;
        private System.Windows.Forms.Label lblPhd;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblMaster;
        private System.Windows.Forms.Label lblStaffType;
        private System.Windows.Forms.Label lblAddr;
        private System.Windows.Forms.Label lblCivil;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.Label lblResAllow;
        private System.Windows.Forms.Label lblGrossSal;
        private System.Windows.Forms.Label lblSpecAllow;
        private System.Windows.Forms.Label lblAcadAllow;
        private System.Windows.Forms.Label lblLivAllow;
        private System.Windows.Forms.Label lblBasicSal;
        private System.Windows.Forms.Label lblStream;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblDeg;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblUni;
    }
}