﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace staffManagementSystem
{
    public partial class EducationalDet : Form
    {
        public EducationalDet()
        {
            InitializeComponent();
        }

        EmployeeDetails employeeDetails = null;
        FinalSub finalSub = null;
        

        public EducationalDet(EmployeeDetails empDetObj)
        {
            employeeDetails = empDetObj;
            InitializeComponent();
        }

        public EducationalDet(FinalSub finalSub)
        {
            finalSub = finalSub;
            InitializeComponent();
        }

        private void btnEmpDet_Click(object sender, EventArgs e)
        {
            if(employeeDetails == null || employeeDetails.IsDisposed)
            {
                employeeDetails = new EmployeeDetails(this);
            }

            employeeDetails.Show();
            this.Hide();
        }

        private void btnFinalSub_Click(object sender, EventArgs e)
        {
            if(finalSub == null || finalSub.IsDisposed)
            {
                finalSub = new FinalSub(this, employeeDetails);
            }

            finalSub.Show();
            this.Hide();
        }

        public string getUni()
        {
            return txtUni.Text;
        }

        public string getStream()
        {
            return comboBoxStream.SelectedItem.ToString();
        }

        public string getYear()
        {
            return txtYear.Text;
        }

        public string getClass()
        {
            return comboBoxClass.SelectedIndex.ToString();
        }

        public string getDegree()
        {
            return txtDeg.Text;
        }

        public string getMaster()
        {
            if (checkBoxMaster.Checked)
            {
                return "Master";
            } else
            {
                return "";
            }
        }

        public string getMphil()
        {
            if (checkBoxMPhil.Checked)
            {
                return "MPhil";
            }
            else
            {
                return "";
            }
        }

        public string getPhd()
        {
            if (checkBoxPhd.Checked)
            {
                return "Phd";
            }
            else
            {
                return "";
            }
        }

        private void EducationalDet_Load(object sender, EventArgs e)
        {

        }
    }
}
