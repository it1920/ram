﻿namespace staffManagementSystem
{
    partial class EducationalDet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxStream = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEmpDet = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxClass = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDeg = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtUni = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBoxPhd = new System.Windows.Forms.CheckBox();
            this.checkBoxMPhil = new System.Windows.Forms.CheckBox();
            this.checkBoxMaster = new System.Windows.Forms.CheckBox();
            this.btnFinalSub = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxStream);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(1157, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Advance Level Details";
            // 
            // comboBoxStream
            // 
            this.comboBoxStream.FormattingEnabled = true;
            this.comboBoxStream.Items.AddRange(new object[] {
            "Maths",
            "Bio",
            "Commerce",
            "Arts",
            "Tech"});
            this.comboBoxStream.Location = new System.Drawing.Point(480, 46);
            this.comboBoxStream.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxStream.Name = "comboBoxStream";
            this.comboBoxStream.Size = new System.Drawing.Size(238, 39);
            this.comboBoxStream.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(370, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Stream : ";
            // 
            // btnEmpDet
            // 
            this.btnEmpDet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpDet.ForeColor = System.Drawing.Color.Red;
            this.btnEmpDet.Location = new System.Drawing.Point(76, 621);
            this.btnEmpDet.Margin = new System.Windows.Forms.Padding(6);
            this.btnEmpDet.Name = "btnEmpDet";
            this.btnEmpDet.Size = new System.Drawing.Size(324, 44);
            this.btnEmpDet.TabIndex = 4;
            this.btnEmpDet.Text = "Employee Details";
            this.btnEmpDet.UseVisualStyleBackColor = true;
            this.btnEmpDet.Click += new System.EventHandler(this.btnEmpDet_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxClass);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtDeg);
            this.groupBox2.Controls.Add(this.txtYear);
            this.groupBox2.Controls.Add(this.txtUni);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox2.Location = new System.Drawing.Point(0, 137);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox2.Size = new System.Drawing.Size(1596, 175);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Undergraduate Details";
            // 
            // comboBoxClass
            // 
            this.comboBoxClass.FormattingEnabled = true;
            this.comboBoxClass.Items.AddRange(new object[] {
            "First ",
            "Second Upper",
            "Second Lower",
            "General"});
            this.comboBoxClass.Location = new System.Drawing.Point(1024, 108);
            this.comboBoxClass.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxClass.Name = "comboBoxClass";
            this.comboBoxClass.Size = new System.Drawing.Size(238, 39);
            this.comboBoxClass.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(954, 115);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 31);
            this.label6.TabIndex = 2;
            this.label6.Text = "Class";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(244, 115);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 31);
            this.label5.TabIndex = 2;
            this.label5.Text = "Degree";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(954, 48);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 31);
            this.label4.TabIndex = 2;
            this.label4.Text = "Year";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 48);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "University ";
            // 
            // txtDeg
            // 
            this.txtDeg.Location = new System.Drawing.Point(364, 110);
            this.txtDeg.Margin = new System.Windows.Forms.Padding(6);
            this.txtDeg.Name = "txtDeg";
            this.txtDeg.Size = new System.Drawing.Size(196, 38);
            this.txtDeg.TabIndex = 1;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(1024, 42);
            this.txtYear.Margin = new System.Windows.Forms.Padding(6);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(196, 38);
            this.txtYear.TabIndex = 1;
            // 
            // txtUni
            // 
            this.txtUni.Location = new System.Drawing.Point(364, 42);
            this.txtUni.Margin = new System.Windows.Forms.Padding(6);
            this.txtUni.Name = "txtUni";
            this.txtUni.Size = new System.Drawing.Size(196, 38);
            this.txtUni.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBoxPhd);
            this.groupBox3.Controls.Add(this.checkBoxMPhil);
            this.groupBox3.Controls.Add(this.checkBoxMaster);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Location = new System.Drawing.Point(0, 323);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox3.Size = new System.Drawing.Size(1596, 175);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Postgraduate Details";
            // 
            // checkBoxPhd
            // 
            this.checkBoxPhd.AutoSize = true;
            this.checkBoxPhd.Location = new System.Drawing.Point(858, 69);
            this.checkBoxPhd.Margin = new System.Windows.Forms.Padding(6);
            this.checkBoxPhd.Name = "checkBoxPhd";
            this.checkBoxPhd.Size = new System.Drawing.Size(97, 35);
            this.checkBoxPhd.TabIndex = 3;
            this.checkBoxPhd.Text = "Phd";
            this.checkBoxPhd.UseVisualStyleBackColor = true;
            // 
            // checkBoxMPhil
            // 
            this.checkBoxMPhil.AutoSize = true;
            this.checkBoxMPhil.Location = new System.Drawing.Point(500, 69);
            this.checkBoxMPhil.Margin = new System.Windows.Forms.Padding(6);
            this.checkBoxMPhil.Name = "checkBoxMPhil";
            this.checkBoxMPhil.Size = new System.Drawing.Size(118, 35);
            this.checkBoxMPhil.TabIndex = 3;
            this.checkBoxMPhil.Text = "MPhil";
            this.checkBoxMPhil.UseVisualStyleBackColor = true;
            // 
            // checkBoxMaster
            // 
            this.checkBoxMaster.AutoSize = true;
            this.checkBoxMaster.Location = new System.Drawing.Point(196, 69);
            this.checkBoxMaster.Margin = new System.Windows.Forms.Padding(6);
            this.checkBoxMaster.Name = "checkBoxMaster";
            this.checkBoxMaster.Size = new System.Drawing.Size(135, 35);
            this.checkBoxMaster.TabIndex = 3;
            this.checkBoxMaster.Text = "Master";
            this.checkBoxMaster.UseVisualStyleBackColor = true;
            // 
            // btnFinalSub
            // 
            this.btnFinalSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalSub.ForeColor = System.Drawing.Color.Red;
            this.btnFinalSub.Location = new System.Drawing.Point(1304, 621);
            this.btnFinalSub.Margin = new System.Windows.Forms.Padding(6);
            this.btnFinalSub.Name = "btnFinalSub";
            this.btnFinalSub.Size = new System.Drawing.Size(248, 44);
            this.btnFinalSub.TabIndex = 6;
            this.btnFinalSub.Text = "Final Report";
            this.btnFinalSub.UseVisualStyleBackColor = true;
            this.btnFinalSub.Click += new System.EventHandler(this.btnFinalSub_Click);
            // 
            // EducationalDet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 698);
            this.Controls.Add(this.btnFinalSub);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnEmpDet);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "EducationalDet";
            this.Text = "Educational Details";
            this.Load += new System.EventHandler(this.EducationalDet_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxStream;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnEmpDet;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxClass;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDeg;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtUni;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBoxPhd;
        private System.Windows.Forms.CheckBox checkBoxMPhil;
        private System.Windows.Forms.CheckBox checkBoxMaster;
        private System.Windows.Forms.Button btnFinalSub;
    }
}