﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalaryLibrary;

namespace staffManagementSystem
{
    public partial class EmployeeDetails : Form
    {
        public EmployeeDetails()
        {
            InitializeComponent();
            comboBoxType.SelectedIndex = 0;
        }

        private EducationalDet educationalDet = null;

        public EmployeeDetails(EducationalDet eduDetObj)
        {
            educationalDet = eduDetObj;
            InitializeComponent();
        }

        

        private void btnCal_Click(object sender, EventArgs e)
        {
            string staffType = comboBoxType.SelectedItem.ToString();
            double basicSal = Int64.Parse(txtBasicSal.Text);

            SalaryLibraryCls salaryLibraryCls = new SalaryLibraryCls(staffType, basicSal);

            txtLivingAllow.Text = 7800.ToString();
            txtSpecAllow.Text = salaryLibraryCls.calSpecialAllow().ToString();
            txtResAllow.Text = salaryLibraryCls.calResearchAllow().ToString();
            txtAcadAllow.Text = salaryLibraryCls.calAcademicAllow().ToString();
            txtMonthlyCompAllow.Text = salaryLibraryCls.calMonthlyCompensAllow().ToString();
            txtGrossSal.Text = salaryLibraryCls.calTotSalary().ToString();
        }


        private void BtnLoadImage_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialogBrowsePhoto.ShowDialog();
            if (result.Equals(DialogResult.OK))
            {
                string fileName = openFileDialogBrowsePhoto.FileName;
                pictureBoxPhoto.Image = Image.FromFile(fileName);
            }

        }

        private void btnEduDet_Click(object sender, EventArgs e)
        {
            if (educationalDet == null || educationalDet.IsDisposed)
            {
                educationalDet = new EducationalDet(this);
            }

            educationalDet.Show();
            this.Hide();
        }

        public string getStaffId()
        {
            return txtStaffID.Text;
        }

        public string getName()
        {
            return txtName.Text;
        }

        public string getSex()
        {
            return txtSex.Text;
        }
        public string getDOB()
        {
            return txtDOB.Text;
        }

        public string getAddr()
        {
            return txtAddress.Text;
        }

        public string getBasic()
        {
            return txtBasicSal.Text;
        }

        public string getLiving()
        {
            return txtLivingAllow.Text;
        }

        public string getSpecial()
        {
            return txtSpecAllow.Text;
        }

        public string getResearch()
        {
            return txtResAllow.Text;
        }
        public string getAcad()
        {
            return txtAcadAllow.Text;
        }
        public string getMonthly()
        {
            return txtMonthlyCompAllow.Text;
        }
        public string getGross()
        {
            return txtGrossSal.Text;
        }

        public string getCivil()
        {
            if (radioBtnSingle.Checked)
            {
                return "Single";
            }
            else
            {
                return "Married";
            }
        }

        public string getType()
        {
            return comboBoxType.SelectedItem.ToString();
        }

        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }


}

