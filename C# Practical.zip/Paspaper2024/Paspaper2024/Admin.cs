﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paspaper2024
{
    public class Admin
    {
        private string username;
        private string password;
        public Admin(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public string getName()
        {
            return username;
        }
    }
}