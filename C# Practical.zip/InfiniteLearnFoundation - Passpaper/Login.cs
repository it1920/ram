﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace InfiniteLearnFoundation
{
    public partial class Login : Form
    {
        User registeredUser;
        Application application = null;
        Register registerForm = null;

        public Login(User registeredUser)
        {
            InitializeComponent();
            this.registeredUser = registeredUser;        
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (registeredUser.email == txtEmail.Text && registeredUser.password == txtPassword.Text)
            {
                application = new Application(registeredUser, true);
                application.Show();
                this.Hide();
            } else
            {
                MessageBox.Show("Email or password wrong!");
            }

            
        }

        private void linkLabelRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(registerForm == null || registerForm.IsDisposed)
            {
                registerForm = new Register();
            }

            this.Hide();
            registerForm.Show();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application application = new Application();
            application.Show();
            this.Hide();
        }
    }
}
