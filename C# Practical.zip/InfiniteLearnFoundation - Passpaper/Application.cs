﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InfiniteLearnFoundation
{
    public partial class Application : Form
    {
        User registeredUser;
        User logedinUser;
        Login loginForm = null;
        Register registerForm = null;
        public Application()
        {
            InitializeComponent();
            this.registeredUser = new User("Emma Stone", "emma@gmail.com", "12345", "Undergraduate student");
        }

        public Application(User registeredUser)
        {
            InitializeComponent();
            this.registeredUser = registeredUser;
        }

        public Application(User logedinUser, bool state)
        {
            InitializeComponent();
            this.logedinUser = logedinUser;
            btnEnroll.Enabled = groupBoxLevel.Enabled = lblCourses.Enabled = lblCate.Enabled = lblAvailCourses.Enabled = lblAddiMate.Enabled = checkBoxQuickGui.Enabled = checkBoxSelfLearnBun.Enabled = listBoxCate.Enabled = listBoxAvailCourses.Enabled = state;
            btnLogin.Text = "Logout";
            lblUser.Text = "Hi " + logedinUser.name;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(btnLogin.Text == "Login")
            {
                if (loginForm == null || loginForm.IsDisposed)
                {
                   loginForm = new Login(registeredUser);
                }

                this.Hide();
                loginForm.Show();
            } else if(btnLogin.Text == "Logout")
            {
                this.logedinUser = null;
                Application application = new Application(registeredUser);
                this.Hide();
                application.Show();
            }
            

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(registerForm == null || registerForm.IsDisposed)
            {
                registerForm = new Register();
            }
            this.Hide();
            registerForm.Show();
        }

        private void listBoxCate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxCate.SelectedIndex == 0)
            {
                listBoxAvailCourses.Items.Clear();
                listBoxAvailCourses.Items.Add("Python for Everybody Specialization");
                listBoxAvailCourses.Items.Add("Harvard's CS50x: Introduction to Computer Science");
                listBoxAvailCourses.Items.Add("Udacity - Full Stack Web Developer Nanodegree");
                listBoxAvailCourses.Items.Add("Pluralsight - C# Fundamentals with Visual Studio");
                listBoxAvailCourses.Items.Add("Codecademy - JavaScript Course");
            }
            else if (listBoxCate.SelectedIndex == 1)
            {
                listBoxAvailCourses.Items.Clear();

                listBoxAvailCourses.Items.Add("Coursera - Data Science Specialization");
                listBoxAvailCourses.Items.Add("edX - Microsoft Professional Program for Data Science");
                listBoxAvailCourses.Items.Add("Udacity - Data Analyst Nanodegree");
                listBoxAvailCourses.Items.Add("LinkedIn Learning - Python for Data Science Essential Training");
                listBoxAvailCourses.Items.Add("DataCamp - Introduction to Machine Learning with Python");
            }
            else if (listBoxCate.SelectedIndex == 2)
            {
                listBoxAvailCourses.Items.Clear();

                listBoxAvailCourses.Items.Add("Udemy - The Complete Software Developer Course");
                listBoxAvailCourses.Items.Add("Pluralsight - Software Development Fundamentals");
                listBoxAvailCourses.Items.Add("LinkedIn Learning - Software Development Lifecycle and Methodologies");
                listBoxAvailCourses.Items.Add("edX - Agile Development Using Ruby on Rails");
                listBoxAvailCourses.Items.Add("Codecademy - Learn Git");
            }
            else if (listBoxCate.SelectedIndex == 3)
            {
                listBoxAvailCourses.Items.Clear();

                listBoxAvailCourses.Items.Add("Udacity - Android Developer Nanodegree");
                listBoxAvailCourses.Items.Add("Coursera - iOS App Development with Swift Specialization");
                listBoxAvailCourses.Items.Add("edX - Xamarin Mobile App Development");
                listBoxAvailCourses.Items.Add("LinkedIn Learning - React Native Essential Training");
                listBoxAvailCourses.Items.Add("Pluralsight - Flutter: Getting Started");
            }
            else if (listBoxCate.SelectedIndex == 4)
            {
                listBoxAvailCourses.Items.Clear();

                listBoxAvailCourses.Items.Add("Coursera - Introduction to Databases and SQL Querying");
                listBoxAvailCourses.Items.Add("edX - Microsoft SQL Server database Fundamentals");
                listBoxAvailCourses.Items.Add("Udemy - The Complete Database Design & Modeling Beginners Tutorial");
                listBoxAvailCourses.Items.Add("LinkedIn Learning - Learning MongoDB");
                listBoxAvailCourses.Items.Add("Pluralsight - Introduction to Oracle: Learn and Understand Oracle Database 19c");
            }
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            double lastPercentage = 1;
            if(logedinUser.eduLevel == "Undergraduate")
            {
                lastPercentage = 0.6;
            }
            if (logedinUser.eduLevel == "Graduate")
            {
                lastPercentage = 0.8;
            }

            double cost = listBoxAvailCourses.SelectedItems.Count * 5000 * lastPercentage;

            int additonalCharge = 500;
            if (radioButtonBegg.Checked)
            {
                additonalCharge = 100;
            }
            if (radioButtonInter.Checked)
            {
                additonalCharge = 200;
            }

            if (checkBoxQuickGui.Checked)
            {
                cost += additonalCharge;
            }
            if (checkBoxSelfLearnBun.Checked)
            {
                cost += additonalCharge;
            }


            DialogResult result = MessageBox.Show("Total Course Fee is " + cost, "Confirmation", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                Enrolled enroll = new Enrolled(logedinUser, listBoxAvailCourses.SelectedItems, checkBoxQuickGui, checkBoxSelfLearnBun, cost );
                enroll.Show();
            }
           
        }
    }
}
