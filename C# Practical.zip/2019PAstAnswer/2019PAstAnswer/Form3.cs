﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2019PAstAnswer
{
    public partial class Form3 : Form
    {
        string aName, aDob, aSex,aFile;
        int aAge = 0, counter = 0;
        Form2 insta;
        public Form3(Form2 instanse)
        {
            InitializeComponent();
            this.insta= instanse;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            insta.Show();
            this.Hide();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
          

            aName = textBox1.Text;
            aDob = dateTimePicker1.Text;
            if (radioButton1.Checked)
            {
                aSex = "Male";
            }
            else if (radioButton2.Checked)
            {
                aSex = "Female";
            }
            aAge = Convert.ToInt32(numericUpDown1.Value);
            aFile = openFileDialog1.FileName;
            Author a1 = new Author(aName,aDob,aSex,aAge,aFile);
            insta.authors[counter]=a1;
            if (a1 == null)
            {
                MessageBox.Show("Array is returned null");
            }
            else
            {
                MessageBox.Show("Author is Added" +insta.authors[counter].Name);
            }
            // Form4.instance.combo.Items.Add(a1.authors[counter].Name)
            counter++;
           
        }
        public int Counter { get; set; }
       /* public Author auth {
            get
            {
                return authors[];
            } 
        }*/
    }
}
