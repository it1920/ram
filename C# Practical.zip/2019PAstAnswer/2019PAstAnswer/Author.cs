﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2019PAstAnswer
{
    public class Author
    {
        private string name;
        private string sex;
        private string dob;
        private int age;
        private string file;
        private Author auther;
       

        public Author() { }

        public Author(string name,string dob,string sex,int age,string file)
        {
            this.name =name;
            this.sex = sex;
            this.dob = dob;
            this.age = age;
            this.file = file;
        }
        public string Name
        {
            get
            { 
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public string Dob
        {
            get
            {
                return this.dob;
            }
            set
            {
                this.dob = value;
            }
        }
        public string Sex
        {
            get
            {
                return this.sex;
            }
            set
            {
                this.sex = value;
            }
        }
        public int Age
        {
            get
            {
                return this.age;
            }
            set
            {
                this.age = value;
            }
        }
        public Author Auth
        { 
            get { return auther; }
            set
            {
                auther = value;
            }
        }
        public string File
        {
            get
            {
                return this.file;
            }
            set
            {
                    this.file = value;
            }
        }



    }
}
